package com.hospital.rest;

import entities.Appointment;
import jakarta.persistence.*;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

@Path("/appointments")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AppointmentResource {

    private static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("HospitalPU");

    @GET
    public Response getAllAppointments() {
        List<Appointment> appointments;
        try (EntityManager em = emf.createEntityManager()) {
            appointments = em.createQuery("SELECT a FROM Appointment a", Appointment.class).getResultList();
        }
        return Response.ok(appointments).build();
    }

    @POST
    public Response createAppointment(Appointment appointment) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();

        try {
            transaction.begin();
            em.persist(appointment);
            transaction.commit();
            return Response.status(Response.Status.CREATED).entity(appointment).build();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            return Response.serverError().entity("Error creating appointment: " + e.getMessage()).build();
        } finally {
            em.close();
        }
    }

    @PUT
    @Path("/{id}")
    public Response updateAppointment(@PathParam("id") int id, Appointment updatedAppointment) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();

        try {
            transaction.begin();
            Appointment appointment = em.find(Appointment.class, id);
            if (appointment == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Appointment not found").build();
            }

            // Use correct field names for LocalDate and LocalTime
            appointment.setPatientName(updatedAppointment.getPatientName());
            appointment.setDoctorName(updatedAppointment.getDoctorName());
            appointment.setAppointmentDate(updatedAppointment.getAppointmentDate());
            appointment.setAppointmentTime(updatedAppointment.getAppointmentTime());

            transaction.commit();
            return Response.ok(appointment).build();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            return Response.serverError().entity("Error updating appointment: " + e.getMessage()).build();
        } finally {
            em.close();
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAppointment(@PathParam("id") int id) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction transaction = em.getTransaction();

        try {
            transaction.begin();
            Appointment appointment = em.find(Appointment.class, id);
            if (appointment == null) {
                return Response.status(Response.Status.NOT_FOUND).entity("Appointment not found").build();
            }
            em.remove(appointment);
            transaction.commit();
            return Response.ok("Appointment deleted successfully.").build();
        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            return Response.serverError().entity("Error deleting appointment: " + e.getMessage()).build();
        } finally {
            em.close();
        }
    }
}
