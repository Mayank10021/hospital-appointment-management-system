package com.hospital.servlets;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/managePatients")
public class PatientServlet extends HttpServlet {
    private final String DB_URL = "jdbc:mysql://localhost:3306/HospitalDB";
    private final String DB_USER = "root";
    private final String DB_PASS = "admin"; // Replace this!

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter();
             Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM patients")) {

            Class.forName("com.mysql.cj.jdbc.Driver");

            out.println("<html><head><title>Manage Patients</title>");
            out.println("<link rel='stylesheet' href='styles.css'/>");
            out.println("<style>body{font-family:Arial;}table{width:90%;margin:auto;border-collapse:collapse;}th,td{padding:12px;border:1px solid #ccc;}th{background:#007bff;color:#fff;}tr:nth-child(even){background:#f2f2f2;}button{padding:6px 12px;margin:2px;border:none;border-radius:4px;} .edit-btn{background:#28a745;color:white;} .delete-btn{background:#dc3545;color:white;}</style>");
            out.println("</head><body><div class='container'>");
            out.println("<h2>Registered Patients</h2>");
            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr>");

            while (rs.next()) {
                int id = rs.getInt("id");
                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + rs.getString("full_name") + "</td>");
                out.println("<td>" + rs.getString("email") + "</td>");
                out.println("<td>" + rs.getString("phone") + "</td>");
                out.println("<td>");
                out.println("<form action='edit-patient.jsp' method='get' style='display:inline;'><input type='hidden' name='id' value='" + id + "'><button class='edit-btn'>Edit</button></form>");
                out.println("<form action='deletePatient' method='post' onsubmit='return confirm(\"Are you sure?\");' style='display:inline;'><input type='hidden' name='id' value='" + id + "'><button class='delete-btn'>Delete</button></form>");
                out.println("</td></tr>");
            }

            out.println("</table></div></body></html>");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<p>Error: " + e.getMessage() + "</p>");
        }
    }
}
