package com.hospital.servlets;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/deletePatient")
public class DeletePatientServlet extends HttpServlet {
    private final String DB_URL = "jdbc:mysql://localhost:3306/HospitalDB";
    private final String DB_USER = "root";
    private final String DB_PASS = "admin"; // Replace this

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idStr = request.getParameter("id");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                PreparedStatement stmt = con.prepareStatement("DELETE FROM patients WHERE id = ?");
                stmt.setInt(1, Integer.parseInt(idStr));
                stmt.executeUpdate();
                response.sendRedirect("managePatients");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
