package com.hospital.servlets;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/updatePatient")
public class UpdatePatientServlet extends HttpServlet {
    private final String DB_URL = "jdbc:mysql://localhost:3306/HospitalDB";
    private final String DB_USER = "root";
    private final String DB_PASS = "admin"; // Replace this

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");
        String name = request.getParameter("full_name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            PreparedStatement ps = con.prepareStatement("UPDATE patients SET name=?, email=?, phone=? WHERE id=?");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, Integer.parseInt(id));
            ps.executeUpdate();
            con.close();

            response.sendRedirect("managePatients");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
