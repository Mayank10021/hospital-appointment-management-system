package rest;

import com.google.gson.*;
import entities.Appointment;
import jakarta.persistence.*;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Path("/appointments")
public class AppointmentService {

    private final EntityManagerFactory emf = Persistence.createEntityManagerFactory("hospitalPU");

    // Gson instance with support for LocalDate and LocalTime
    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(LocalDate.class, new JsonDeserializer<LocalDate>() {
                public LocalDate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
                        throws JsonParseException {
                    return LocalDate.parse(json.getAsString());
                }
            })
            .registerTypeAdapter(LocalDate.class, new JsonSerializer<LocalDate>() {
                public JsonElement serialize(LocalDate date, Type typeOfSrc, JsonSerializationContext context) {
                    return new JsonPrimitive(date.toString());
                }
            })
            .registerTypeAdapter(LocalTime.class, new JsonDeserializer<LocalTime>() {
                public LocalTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
                        throws JsonParseException {
                    return LocalTime.parse(json.getAsString());
                }
            })
            .registerTypeAdapter(LocalTime.class, new JsonSerializer<LocalTime>() {
                public JsonElement serialize(LocalTime time, Type typeOfSrc, JsonSerializationContext context) {
                    return new JsonPrimitive(time.toString());
                }
            })
            .create();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAppointments() {
        try (EntityManager em = emf.createEntityManager()) {
            List<Appointment> appointments = em.createQuery("SELECT a FROM Appointment a", Appointment.class)
                                               .getResultList();
            return Response.ok(gson.toJson(appointments)).build();
        } catch (Exception e) {
            return Response.serverError()
                           .entity("{\"message\":\"Error fetching appointments: " + e.getMessage() + "\"}")
                           .build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAppointment(String json) {
        try {
            Appointment appointment = gson.fromJson(json, Appointment.class);

            if (appointment.getPatientName() == null || appointment.getDoctorName() == null ||
                appointment.getAppointmentDate() == null || appointment.getAppointmentTime() == null) {
                return Response.status(Response.Status.BAD_REQUEST)
                               .entity("{\"message\":\"Invalid input\"}").build();
            }

            EntityManager em = emf.createEntityManager();
            try {
                em.getTransaction().begin();
                em.persist(appointment);
                em.getTransaction().commit();
                return Response.status(Response.Status.CREATED)
                               .entity("{\"message\":\"Appointment created\"}").build();
            } catch (Exception e) {
                return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                               .entity("{\"message\":\"Error creating appointment: " + e.getMessage() + "\"}")
                               .build();
            } finally {
                em.close();
            }
        } catch (JsonSyntaxException e) {
            return Response.status(Response.Status.BAD_REQUEST)
                           .entity("{\"message\":\"Invalid JSON format\"}").build();
        }
    }
}
