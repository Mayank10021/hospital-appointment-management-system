package servlets;

import entities.Doctor;
import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/RemoveDoctorServlet")
public class RemoveDoctorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    EntityManagerFactory emf;

    @Override
    public void init() {
        emf = Persistence.createEntityManagerFactory("hospitalPU");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String doctorIdStr = request.getParameter("doctorId");

        if (doctorIdStr != null) {
            int doctorId = Integer.parseInt(doctorIdStr);

            EntityManager em = emf.createEntityManager();
            EntityTransaction transaction = em.getTransaction();

            try {
                transaction.begin();
                Doctor doctor = em.find(Doctor.class, doctorId);
                if (doctor != null) {
                    em.remove(doctor);
                }
                transaction.commit();
            } catch (Exception e) {
                if (transaction.isActive()) transaction.rollback();
                e.printStackTrace();
            } finally {
                em.close();
            }
        }

        // Redirect back to view-doctors.jsp
        response.sendRedirect("view-doctors.jsp");
    }

    @Override
    public void destroy() {
        if (emf != null && emf.isOpen()) {
            emf.close();
        }
    }
}
