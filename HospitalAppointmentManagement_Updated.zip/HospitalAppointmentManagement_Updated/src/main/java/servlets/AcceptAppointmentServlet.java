package servlets;

import jakarta.persistence.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/AcceptAppointmentServlet")
public class AcceptAppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    EntityManagerFactory emf;

    @Override
    public void init() {
        emf = Persistence.createEntityManagerFactory("hospitalPU");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int appointmentId = Integer.parseInt(request.getParameter("appointmentId"));
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            Query query = em.createQuery("UPDATE Appointment a SET a.status = :status WHERE a.id = :id");
            query.setParameter("status", "Accepted");
            query.setParameter("id", appointmentId);
            int rows = query.executeUpdate();
            tx.commit();

            if (rows > 0) {
                response.setStatus(HttpServletResponse.SC_OK); // 200
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND); // 404
            }
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // 500
        } finally {
            em.close();
        }
    }

    @Override
    public void destroy() {
        if (emf != null) emf.close();
    }
}
