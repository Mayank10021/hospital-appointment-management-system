package servlets;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ReportsServlet")
public class ReportsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int doctorCount = 0;
        int patientCount = 0;
        int appointmentCount = 0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/HospitalDB", "root", "admin");

            Statement stmt = con.createStatement();
            ResultSet rs1 = stmt.executeQuery("SELECT COUNT(*) FROM doctors");
            if (rs1.next()) doctorCount = rs1.getInt(1);

            ResultSet rs2 = stmt.executeQuery("SELECT COUNT(*) FROM patients");
            if (rs2.next()) patientCount = rs2.getInt(1);

            ResultSet rs3 = stmt.executeQuery("SELECT COUNT(*) FROM appointments");
            if (rs3.next()) appointmentCount = rs3.getInt(1);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("doctorCount", doctorCount);
        request.setAttribute("patientCount", patientCount);
        request.setAttribute("appointmentCount", appointmentCount);

        RequestDispatcher rd = request.getRequestDispatcher("reports.jsp");
        rd.forward(request, response);
    }
}
