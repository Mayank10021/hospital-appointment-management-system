package servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import jakarta.persistence.*;

import entities.Admin;

import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private EntityManagerFactory emf;

    @Override
    public void init() {
        emf = Persistence.createEntityManagerFactory("hospitalPU");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        EntityManager em = emf.createEntityManager();

        try {
            TypedQuery<Admin> query = em.createQuery(
                "SELECT a FROM Admin a WHERE a.email = :email AND a.password = :password", Admin.class);
            query.setParameter("email", email);
            query.setParameter("password", password);

            Admin admin = query.getSingleResult();

            // Login success
            HttpSession session = request.getSession();
            session.setAttribute("admin", admin);
            response.sendRedirect("admin-dashboard.jsp");

        } catch (NoResultException e) {
            // Login failure
            request.setAttribute("message", "❌ Invalid email or password");
            request.getRequestDispatcher("login.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "⚠️ Internal server error");
            request.getRequestDispatcher("login.jsp").forward(request, response);

        } finally {
            em.close();
        }
    }

    @Override
    public void destroy() {
        emf.close();
    }
}
