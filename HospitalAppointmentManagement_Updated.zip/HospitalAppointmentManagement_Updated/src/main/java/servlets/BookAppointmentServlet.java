package servlets;

import com.google.gson.*;
import entities.Appointment;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

@WebServlet("/book")
public class BookAppointmentServlet extends HttpServlet {
    private EntityManagerFactory emf;

    private final Gson gson = new GsonBuilder()
            .registerTypeAdapter(LocalDate.class, (JsonDeserializer<LocalDate>)
                    (json, type, context) -> LocalDate.parse(json.getAsString()))
            .registerTypeAdapter(LocalTime.class, (JsonDeserializer<LocalTime>)
                    (json, type, context) -> LocalTime.parse(json.getAsString()))
            .create();

    @Override
    public void init() throws ServletException {
        emf = Persistence.createEntityManagerFactory("hospitalPU");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        Appointment appointment = gson.fromJson(reader, Appointment.class);

        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();
            em.persist(appointment);
            em.getTransaction().commit();

            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_CREATED);
            response.getWriter().write("{\"message\":\"Appointment booked successfully\"}");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\":\"Could not save appointment. " + e.getMessage() + "\"}");
        } finally {
            em.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        response.getWriter().write("{\"error\":\"GET method not supported on /book. Please use POST.\"}");
    }

    @Override
    public void destroy() {
        if (emf != null) {
            emf.close();
        }
    }
}
