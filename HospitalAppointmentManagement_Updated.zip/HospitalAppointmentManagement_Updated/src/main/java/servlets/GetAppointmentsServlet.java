package servlets;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.sql.*;

@WebServlet("/getAppointments")
public class GetAppointmentsServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/HospitalDB";
    private static final String DB_USER = "root"; // change if needed
    private static final String DB_PASSWORD = "admin"; // change if needed

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        Gson gson = new Gson();

        JsonArray appointmentsArray = new JsonArray();

        System.out.println("📡 [GetAppointmentsServlet] Incoming GET request...");

        try (PrintWriter out = response.getWriter()) {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("✅ JDBC Driver loaded.");

            // Connect to database
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement("SELECT * FROM appointments");
                 ResultSet rs = stmt.executeQuery()) {

                System.out.println("🔗 Connected to DB. Fetching appointments...");

                while (rs.next()) {
                    JsonObject appointment = new JsonObject();
                    appointment.addProperty("id", rs.getInt("id"));
                    appointment.addProperty("patient_name", rs.getString("patient_name"));
                    appointment.addProperty("doctor_name", rs.getString("doctor_name"));
                    appointment.addProperty("date", rs.getString("date"));
                    appointment.addProperty("time", rs.getString("time"));
                    appointmentsArray.add(appointment);

                    // Log each row
                    System.out.println("📄 Fetched: " + rs.getInt("id") + ", " +
                            rs.getString("patient_name") + ", " +
                            rs.getString("doctor_name"));
                }

                out.print(gson.toJson(appointmentsArray));
                System.out.println("✅ JSON response sent.");
            }
        } catch (Exception e) {
            System.out.println("❌ Error in GetAppointmentsServlet:");
            e.printStackTrace();

            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject error = new JsonObject();
            error.addProperty("error", "Unable to fetch appointments.");
            try (PrintWriter out = response.getWriter()) {
                out.print(gson.toJson(error));
            }
        }
    }
}
